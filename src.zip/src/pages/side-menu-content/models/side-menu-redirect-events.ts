// SideMenuRedirectEvent constant
export const SideMenuRedirectEvent: string = 'sidemenu:redirect';

// SideMenuRedirectEventData interface
export interface SideMenuRedirectEventData {
	displayName?: string;
}